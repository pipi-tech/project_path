#!/bin/bash
# WHAT:  Verifies PP_ROOT resolves correctly from any clone location
# WIRES: Tests functions.sh → PP_ROOT export
# WHY:   Portability is the #1 public repo issue — catches hardcoded path regressions

PASS=0; FAIL=0

source "$(dirname "$0")/../functions.sh"

if [ -n "$PP_ROOT" ] && [ -d "$PP_ROOT" ]; then
  echo "PASS: PP_ROOT resolved → $PP_ROOT"; ((PASS++))
else
  echo "FAIL: PP_ROOT not set or not a directory"; ((FAIL++))
fi

# Should not contain hardcoded user paths
if echo "$PP_ROOT" | grep -qE "^/home/[^/]+/project/project_path$"; then
  echo "WARN: PP_ROOT looks like it may be a dev install path (ok if intentional)"
else
  echo "PASS: PP_ROOT resolved from script location"; ((PASS++))
fi

for path in cmd/builder engines/builder/src data functions; do
  if [ -d "$PP_ROOT/$path" ]; then
    echo "PASS: $path exists under PP_ROOT"; ((PASS++))
  else
    echo "FAIL: $path missing under PP_ROOT"; ((FAIL++))
  fi
done

echo ""
echo "--- $PASS passed, $FAIL failed"
[ $FAIL -eq 0 ] && exit 0 || exit 1
